#include "target.h"
#include "util.h"
#include <ole2.h>
#include <oleacc.h>
#include <uiautomation.h>
#include <tlhelp32.h>
#include <algorithm>
#include <cwctype>
#include <map>

// ---------------------------------------------------------------- UIA glue

static IUIAutomation* Uia() {
    static IUIAutomation* uia = nullptr;
    static bool tried = false;
    if (!tried) {
        tried = true;
        CoCreateInstance(CLSID_CUIAutomation, nullptr, CLSCTX_INPROC_SERVER,
                         IID_PPV_ARGS(&uia));
    }
    return uia;
}

static std::wstring CurrentString(IUIAutomationElement* e,
                                  HRESULT (STDMETHODCALLTYPE IUIAutomationElement::*getter)(BSTR*)) {
    BSTR b = nullptr;
    std::wstring s;
    if (SUCCEEDED((e->*getter)(&b)) && b) {
        s.assign(b, SysStringLen(b));
        SysFreeString(b);
    }
    return s;
}

// ------------------------------------------------------------- hit testing

static bool PointOnTaskbar(POINT pt) {
    struct Ctx { POINT pt; bool hit; } ctx{pt, false};

    EnumWindows([](HWND h, LPARAM lp) -> BOOL {
        Ctx* c = reinterpret_cast<Ctx*>(lp);
        wchar_t cls[64];
        if (!GetClassNameW(h, cls, 64)) return TRUE;
        if (_wcsicmp(cls, L"Shell_TrayWnd") && _wcsicmp(cls, L"Shell_SecondaryTrayWnd"))
            return TRUE;
        RECT r;
        if (GetWindowRect(h, &r) && PtInRect(&r, c->pt)) {
            c->hit = true;
            return FALSE;
        }
        return TRUE;
    }, reinterpret_cast<LPARAM>(&ctx));

    return ctx.hit;
}

static bool TitleMatchesVisibleWindow(const std::wstring& title) {
    struct Ctx { const std::wstring* t; bool hit; } ctx{&title, false};
    if (title.empty()) return false;

    EnumWindows([](HWND h, LPARAM lp) -> BOOL {
        Ctx* c = reinterpret_cast<Ctx*>(lp);
        if (!IsWindowVisible(h) || IsCloaked(h)) return TRUE;
        if (GetAncestor(h, GA_ROOT) != h) return TRUE;
        if (GetWindow(h, GW_OWNER)) return TRUE;
        wchar_t buf[512] = {};
        GetWindowTextW(h, buf, 512);
        if (buf[0] && IEquals(buf, *c->t)) {
            c->hit = true;
            return FALSE;
        }
        return TRUE;
    }, reinterpret_cast<LPARAM>(&ctx));

    return ctx.hit;
}

static TaskbarHit HitTestXamlTaskbarButton(POINT pt) {
    TaskbarHit out;

    IUIAutomation* uia = Uia();
    if (!uia) return out;

    ComPtr<IUIAutomationElement> el;
    if (FAILED(uia->ElementFromPoint(pt, el.put())) || !el) return out;

    ComPtr<IUIAutomationTreeWalker> walker;
    uia->get_ControlViewWalker(walker.put());

    ComPtr<IUIAutomationElement> cur;
    cur.attach(el.get());
    el.get()->AddRef();

    for (int i = 0; i < 5 && cur; ++i) {
        CONTROLTYPEID ct = 0;
        cur->get_CurrentControlType(&ct);
        if (ct == UIA_ButtonControlTypeId) break;
        ComPtr<IUIAutomationElement> parent;
        if (!walker || FAILED(walker->GetParentElement(cur.get(), parent.put())) || !parent) {
            cur.reset();
            break;
        }
        cur = std::move(parent);
    }
    if (!cur) return out;

    CONTROLTYPEID ct = 0;
    cur->get_CurrentControlType(&ct);
    if (ct != UIA_ButtonControlTypeId) return out;

    const std::wstring cls  = CurrentString(cur.get(), &IUIAutomationElement::get_CurrentClassName);
    const std::wstring name = CurrentString(cur.get(), &IUIAutomationElement::get_CurrentName);
    const std::wstring aid  = CurrentString(cur.get(), &IUIAutomationElement::get_CurrentAutomationId);

    if (StartsWithI(aid, L"Appid:")) out.appId = aid.substr(6);
    out.title = name;

    // Gate: only accept things that look like task-list buttons. The tray,
    // clock and start button are buttons too, but never match these rules.
    bool looksLikeTaskButton = IContains(cls, L"tasklistbutton") || !out.appId.empty();
    if (!looksLikeTaskButton && !name.empty())
        looksLikeTaskButton = TitleMatchesVisibleWindow(name);
    if (!looksLikeTaskButton) return out;

    out.onButton = true;
    return out;
}

// ------------------------------------------------- Win10 classic taskbar

static std::wstring StripRunningSuffix(std::wstring s);

static HWND FindClassicTaskList(POINT pt) {
    struct TopCtx { POINT pt; HWND list; };

    TopCtx top{pt, nullptr};
    EnumWindows([](HWND bar, LPARAM lp) -> BOOL {
        auto* c = reinterpret_cast<TopCtx*>(lp);
        wchar_t cls[64] = {};
        if (!GetClassNameW(bar, cls, 64)) return TRUE;
        if (_wcsicmp(cls, L"Shell_TrayWnd") && _wcsicmp(cls, L"Shell_SecondaryTrayWnd"))
            return TRUE;

        RECT br{};
        if (!GetWindowRect(bar, &br) || !PtInRect(&br, c->pt)) return TRUE;

        struct ChildCtx { POINT pt; HWND* out; };
        ChildCtx cc{c->pt, &c->list};
        EnumChildWindows(bar, [](HWND child, LPARAM lp2) -> BOOL {
            auto* c2 = reinterpret_cast<ChildCtx*>(lp2);
            wchar_t cls2[64] = {};
            if (!GetClassNameW(child, cls2, 64)) return TRUE;
            if (_wcsicmp(cls2, L"MSTaskListWClass")) return TRUE;
            RECT r{};
            if (!GetWindowRect(child, &r) || !PtInRect(&r, c2->pt)) return TRUE;
            *c2->out = child;
            return FALSE;
        }, reinterpret_cast<LPARAM>(&cc));

        return c->list ? FALSE : TRUE;
    }, reinterpret_cast<LPARAM>(&top));

    return top.list;
}

static bool HitTestClassicTaskbar(POINT pt, TaskbarHit& out) {
    HWND list = FindClassicTaskList(pt);
    if (!list) return false;

    IAccessible* acc = nullptr;
    if (FAILED(AccessibleObjectFromWindow(list, (DWORD)OBJID_CLIENT, IID_IAccessible,
                                          reinterpret_cast<void**>(&acc))) || !acc)
        return false;

    long count = 0;
    if (SUCCEEDED(acc->get_accChildCount(&count))) {
        for (long i = 1; i <= count; ++i) {
            VARIANT child;
            VariantInit(&child);
            child.vt = VT_I4;
            child.lVal = i;

            long x = 0, y = 0, w = 0, h = 0;
            if (SUCCEEDED(acc->accLocation(&x, &y, &w, &h, child)) && w > 0 && h > 0) {
                RECT r{x, y, x + w, y + h};
                if (PtInRect(&r, pt)) {
                    BSTR name = nullptr;
                    if (SUCCEEDED(acc->get_accName(child, &name)) && name) {
                        if (SysStringLen(name) > 0) {
                            out.title = StripRunningSuffix(std::wstring(name, SysStringLen(name)));
                            SysFreeString(name);
                            VariantClear(&child);
                            break;
                        }
                        SysFreeString(name);
                    }
                }
            }
            VariantClear(&child);
        }
    }
    acc->Release();

    out.onButton = !out.title.empty();
    return out.onButton;
}

TaskbarHit HitTestTaskbarButton(POINT pt) {
    TaskbarHit out;
    if (!PointOnTaskbar(pt)) return out;

    out = HitTestXamlTaskbarButton(pt);
    if (out.onButton) return out;

    out = {};
    HitTestClassicTaskbar(pt, out);
    return out;
}

// --------------------------------------------------------------- resolution

static bool SameAppId(const std::wstring& aumid, const std::wstring& appId) {
    if (aumid.empty() || appId.empty()) return false;
    if (IEquals(aumid, appId)) return true;

    // "PackageFamily_8wekyb3d8bbwe!App" style: compare the package part.
    auto family = [](const std::wstring& s) {
        auto p = s.find(L'!');
        return p == std::wstring::npos ? s : s.substr(0, p);
    };
    if (aumid.find(L'!') != std::wstring::npos || appId.find(L'!') != std::wstring::npos)
        return IEquals(family(aumid), family(appId));

    return false;
}

// Win10 taskbar buttons are named "Discord - 1 running window".
static std::wstring StripRunningSuffix(std::wstring s) {
    const auto pos = s.rfind(L" - ");
    if (pos == std::wstring::npos) return s;

    const std::wstring tail = ToLower(s.substr(pos + 3));
    static const wchar_t* kHints[] = {
        L"running window", L"fenêtre", L"fenster", L"ventana", L"finestra",
        L"janela", L"venster", L"okno", L"окн", L"pencere",
        L"窗口", L"ウィンドウ", L"창",
    };
    for (auto* hint : kHints)
        if (tail.find(hint) != std::wstring::npos) return s.substr(0, pos);
    return s;
}

// --------------------------------------------------- process metadata
//
// The jump list only gives us a display name ("LibreWolf", "Settings", "cmd").
// Visible windows are the best first signal, but UWP apps have no top-level
// window of their own and grouped buttons can have titles that never contain
// the label. Exe names and version strings close that gap.

static std::wstring Trim(std::wstring s) {
    auto isSpace = [](wchar_t c) {
        return c == L' ' || c == L'\t' || c == L'\r' || c == L'\n';
    };
    while (!s.empty() && isSpace(s.front())) s.erase(s.begin());
    while (!s.empty() && isSpace(s.back())) s.pop_back();
    return s;
}

static std::wstring WithoutExeSuffix(std::wstring s) {
    if (s.size() > 4 && _wcsicmp(s.c_str() + s.size() - 4, L".exe") == 0)
        s.resize(s.size() - 4);
    return s;
}

// Lowercase alphanumerics only, so spacing and punctuation do not matter:
// "Google Chrome for Testing" -> "googlechromefortesting",
// "OpencodeUnlimited-Multi.exe" -> "opencodeunlimitedmultiexe".
static std::wstring NormalizeName(const std::wstring& s) {
    std::wstring out;
    out.reserve(s.size());
    for (wchar_t c : s)
        if (iswalnum(c)) out.push_back((wchar_t)towlower(c));
    return out;
}

static bool IsExplorerTitle(const std::wstring& title) {
    static const wchar_t* kNames[] = {
        L"File Explorer", L"Explorateur de fichiers", L"Explorador de archivos",
        L"Explorador de arquivos", L"Datei-Explorer", L"Esplora file",
    };
    for (auto* n : kNames)
        if (IEquals(title, n)) return true;
    return false;
}

// Never kill the processes that keep the shell itself alive. Explorer is
// handled separately: only the File Explorer row is allowed to kill it.
static bool IsSystemImage(const std::wstring& exeName) {
    static const wchar_t* kNames[] = {
        L"system", L"idle", L"registry", L"memcompression",
        L"smss.exe", L"csrss.exe", L"wininit.exe", L"winlogon.exe",
        L"services.exe", L"lsass.exe", L"svchost.exe", L"fontdrvhost.exe",
        L"dwm.exe", L"sihost.exe", L"taskhostw.exe", L"runtimebroker.exe",
        L"dllhost.exe", L"ctfmon.exe", L"searchapp.exe",
        L"startmenuexperiencehost.exe", L"shellexperiencehost.exe",
        L"applicationframehost.exe", L"textinputhost.exe",
        L"endtaskhelper.exe", L"endtaskmanager.exe",
    };
    for (auto* n : kNames)
        if (IEquals(exeName, n)) return true;
    return false;
}

struct VersionStrings {
    std::wstring description;
    std::wstring product;
    std::wstring original;
};

static VersionStrings ReadVersionStrings(const std::wstring& path) {
    VersionStrings vs;

    DWORD dummy = 0;
    const DWORD size = GetFileVersionInfoSizeW(path.c_str(), &dummy);
    if (!size) return vs;

    std::vector<BYTE> data(size);
    if (!GetFileVersionInfoW(path.c_str(), 0, size, data.data())) return vs;

    struct Translation { WORD lang; WORD codepage; };
    Translation* tr = nullptr;
    UINT trSize = 0;
    std::vector<Translation> translations;
    if (VerQueryValueW(data.data(), L"\\VarFileInfo\\Translation",
                       reinterpret_cast<LPVOID*>(&tr), &trSize) &&
        trSize >= sizeof(Translation)) {
        translations.assign(tr, tr + trSize / sizeof(Translation));
    }
    if (translations.empty()) translations.push_back(Translation{0x0409, 0x04B0});

    auto query = [&](const wchar_t* key) -> std::wstring {
        for (const auto& t : translations) {
            wchar_t sub[128] = {};
            swprintf_s(sub, L"\\StringFileInfo\\%04x%04x\\%s",
                       t.lang, t.codepage, key);
            wchar_t* val = nullptr;
            UINT valSize = 0;
            if (VerQueryValueW(data.data(), sub,
                               reinterpret_cast<LPVOID*>(&val), &valSize) &&
                val && valSize) {
                std::wstring s(val, valSize);
                while (!s.empty() && s.back() == L'\0') s.pop_back();
                if (!s.empty()) return s;
            }
        }
        return {};
    };

    vs.description = query(L"FileDescription");
    vs.product = query(L"ProductName");
    vs.original = query(L"OriginalFilename");
    return vs;
}

static const VersionStrings& GetVersionStrings(const std::wstring& path) {
    static std::map<std::wstring, VersionStrings> cache;
    const std::wstring key = ToLower(path);
    auto it = cache.find(key);
    if (it != cache.end()) return it->second;
    return cache.emplace(key, ReadVersionStrings(path)).first->second;
}

struct ProcessMeta {
    DWORD pid = 0;
    std::wstring exePath;
    std::wstring exeName;
    std::wstring baseName;
};

static std::vector<ProcessMeta> EnumerateProcesses() {
    std::vector<ProcessMeta> out;

    HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (snap == INVALID_HANDLE_VALUE) return out;

    PROCESSENTRY32W pe{};
    pe.dwSize = sizeof(pe);
    if (Process32FirstW(snap, &pe)) {
        do {
            if (pe.th32ProcessID == 0 || pe.th32ProcessID == 4 ||
                pe.th32ProcessID == GetCurrentProcessId())
                continue;

            ProcessMeta m;
            m.pid = pe.th32ProcessID;
            m.exePath = ProcessImagePath(m.pid);
            m.exeName = m.exePath.empty() ? pe.szExeFile : FileNameOf(m.exePath);
            m.baseName = m.exeName;
            const auto dot = m.baseName.rfind(L'.');
            if (dot != std::wstring::npos) m.baseName = m.baseName.substr(0, dot);
            out.push_back(std::move(m));
        } while (Process32NextW(snap, &pe));
    }
    CloseHandle(snap);
    return out;
}

static int ScoreProcessMeta(const ProcessMeta& p, const std::wstring& title) {
    const std::wstring nt = NormalizeName(WithoutExeSuffix(title));
    int score = 0;
    auto bump = [&](int v) { if (v > score) score = v; };

    // Cheap checks first: most targets match on the exe name alone, and
    // reading the version resource of every process is slow.
    if (IEquals(p.exeName, title)) bump(98);
    if (IEquals(p.baseName, title)) bump(96);
    if (!nt.empty()) {
        if (NormalizeName(p.exeName) == nt) bump(95);
        if (NormalizeName(p.baseName) == nt) bump(94);
    }
    if (score > 0) return score;

    const auto& vs = GetVersionStrings(p.exePath);
    if (!nt.empty()) {
        if (NormalizeName(vs.description) == nt) bump(93);
        if (NormalizeName(vs.product) == nt) bump(92);
        if (NormalizeName(vs.original) == nt) bump(91);

        // Localized/partial labels: "Photos" for "Microsoft Photos",
        // "Store" for "Microsoft Store". Only used when nothing better exists.
        if (nt.size() >= 4) {
            auto suffix = [&](const std::wstring& hay) {
                const std::wstring n = NormalizeName(hay);
                return n.size() > nt.size() &&
                       n.compare(n.size() - nt.size(), nt.size(), nt) == 0;
            };
            auto prefix = [&](const std::wstring& hay) {
                const std::wstring n = NormalizeName(hay);
                return n.size() > nt.size() &&
                       n.compare(0, nt.size(), nt) == 0;
            };
            if (suffix(vs.description) || suffix(vs.product)) bump(78);
            else if (prefix(vs.description) || prefix(vs.product)) bump(76);
        }
    }

    return score;
}

struct Match {
    DWORD pid = 0;
    int score = 0;
};

static int ScoreWindow(const TaskbarHit& hit, HWND h, DWORD pid) {
    wchar_t title[512] = {};
    GetWindowTextW(h, title, 512);
    const std::wstring t = title;

    // The jump list itself is a top-level window titled "Jump List for X".
    // It contains the app name and would turn a single weak match into an
    // ambiguous one, so never score shell flyouts.
    if (StartsWithI(t, L"Jump List") ||
        StartsWithI(t, L"Liste de raccourcis") ||
        StartsWithI(t, L"Liste des raccourcis"))
        return 0;

    const std::wstring exe = ProcessImagePath(pid);
    const std::wstring exeName = FileNameOf(exe);
    std::wstring base = exeName;
    const auto dot = base.rfind(L'.');
    if (dot != std::wstring::npos) base = base.substr(0, dot);

    int score = 0;
    auto bump = [&](int v) { if (v > score) score = v; };

    if (!hit.appId.empty()) {
        if (SameAppId(GetWindowAumid(h), hit.appId)) bump(100);
        if (IEquals(exe, hit.appId) || IEquals(exeName, hit.appId) || IEquals(base, hit.appId))
            bump(100);
    }

    if (!hit.title.empty()) {
        if (IEquals(t, hit.title)) bump(95);
        if (IEquals(base, hit.title) || IEquals(exeName, hit.title)) bump(92);
        if (StartsWithI(t, hit.title + L" - ") || StartsWithI(t, hit.title + L" | "))
            bump(85);

        // Explorer's process name never matches its button label.
        if (IsExplorerTitle(hit.title) && IEquals(base, L"explorer"))
            bump(100);

        // Weak signals, only used when nothing better exists.
        if (IContains(t, hit.title)) bump(55);
        if (IContains(base, hit.title)) bump(50);
    }

    return score;
}

struct EnumCtx {
    const TaskbarHit* hit;
    std::vector<Match> matches;
};

static BOOL CALLBACK WindowProc(HWND h, LPARAM lp) {
    auto* c = reinterpret_cast<EnumCtx*>(lp);

    if (!IsWindowVisible(h) || IsCloaked(h)) return TRUE;
    if (GetAncestor(h, GA_ROOT) != h) return TRUE;
    if (GetWindow(h, GW_OWNER) != nullptr) return TRUE;

    wchar_t cls[128] = {};
    if (GetClassNameW(h, cls, 128)) {
        if (!_wcsicmp(cls, L"Progman") || !_wcsicmp(cls, L"WorkerW") ||
            !_wcsicmp(cls, L"Shell_TrayWnd") || !_wcsicmp(cls, L"Shell_SecondaryTrayWnd") ||
            !_wcsicmp(cls, L"Windows.UI.Core.CoreWindow") ||
            !_wcsicmp(cls, L"ApplicationFrameWindow"))
            return TRUE;
    }

    DWORD pid = 0;
    GetWindowThreadProcessId(h, &pid);
    if (!pid || pid == GetCurrentProcessId()) return TRUE;

    const int score = ScoreWindow(*c->hit, h, pid);
    if (score <= 0) return TRUE;

    for (auto& m : c->matches) {
        if (m.pid == pid) {
            if (score > m.score) m.score = score;
            return TRUE;
        }
    }
    c->matches.push_back(Match{pid, score});
    return TRUE;
}

std::vector<DWORD> ResolveProcesses(const TaskbarHit& hit) {
    EnumCtx ctx{&hit, {}};
    EnumWindows(WindowProc, reinterpret_cast<LPARAM>(&ctx));

    int top = 0;
    for (const auto& m : ctx.matches) top = std::max(top, m.score);

    std::vector<DWORD> out;
    if (top >= 80) {
        for (const auto& m : ctx.matches)
            if (m.score >= 80) out.push_back(m.pid);
    } else if (top >= 55) {
        // Grouped buttons ("cmd - 2 running windows", two Chrome windows)
        // produce several weak matches. Accept them when they are all the
        // same executable; otherwise the label is too ambiguous to guess.
        std::vector<Match> weak;
        for (const auto& m : ctx.matches)
            if (m.score >= 55) weak.push_back(m);

        bool sameExe = true;
        std::wstring firstExe;
        for (const auto& m : weak) {
            const std::wstring exe = ProcessImagePath(m.pid);
            if (firstExe.empty()) firstExe = exe;
            else if (!IEquals(exe, firstExe)) { sameExe = false; break; }
        }
        if (!weak.empty() && (weak.size() == 1 || sameExe))
            for (const auto& m : weak) out.push_back(m.pid);
    }

    // Old UWP hosts are shared by several apps: never kill them. Explorer is
    // only a valid target for its own jump list, not for Control Panel or any
    // other shell surface hosted by explorer.exe.
    std::vector<DWORD> filtered;
    for (DWORD pid : out) {
        const std::wstring exe = FileNameOf(ProcessImagePath(pid));
        if (IsSystemImage(exe)) continue;
        if (IEquals(exe, L"explorer.exe") && !IsExplorerTitle(hit.title)) continue;
        if (std::find(filtered.begin(), filtered.end(), pid) == filtered.end())
            filtered.push_back(pid);
    }
    return filtered;
}

std::vector<DWORD> ResolveProcessesByName(const std::wstring& appName) {
    const std::wstring title = Trim(appName);
    std::vector<DWORD> out;
    if (title.empty()) return out;

    const auto procs = EnumerateProcesses();

    if (IsExplorerTitle(title)) {
        for (const auto& p : procs)
            if (IEquals(p.exeName, L"explorer.exe")) out.push_back(p.pid);
        return out;
    }

    struct Candidate {
        DWORD pid;
        int score;
        std::wstring exe;
    };
    std::vector<Candidate> candidates;

    for (const auto& p : procs) {
        if (IsSystemImage(p.exeName)) continue;
        if (IEquals(p.exeName, L"explorer.exe")) continue;

        const int score = ScoreProcessMeta(p, title);
        if (score > 0) candidates.push_back(Candidate{p.pid, score, p.exePath});
    }
    if (candidates.empty()) return out;

    int top = 0;
    for (const auto& c : candidates) top = std::max(top, c.score);
    if (top < 70) return out;

    // Only take the best tier, and only when every process in it is the same
    // executable. This kills all Chrome/Electron helpers for the app but never
    // mixes two different programs that happen to share a word.
    std::wstring firstExe;
    for (const auto& c : candidates) {
        if (c.score != top) continue;
        if (firstExe.empty()) firstExe = c.exe;
        else if (!IEquals(firstExe, c.exe)) return {};
        out.push_back(c.pid);
    }

    std::sort(out.begin(), out.end());
    out.erase(std::unique(out.begin(), out.end()), out.end());
    return out;
}

bool KillByImageName(const std::wstring& appName) {
    std::wstring image = Trim(appName);
    if (image.empty()) return false;

    // A display name is not a path. Refuse anything that could turn into a
    // wildcard or an unrelated file name.
    for (wchar_t c : image) {
        if (c == L'\\' || c == L'/' || c == L':' || c == L'"' ||
            c == L'*' || c == L'?' || c == L'|' || c == L'<' || c == L'>')
            return false;
    }
    if (image.size() <= 4 || _wcsicmp(image.c_str() + image.size() - 4, L".exe") != 0)
        image += L".exe";
    if (IsSystemImage(image)) return false;
    if (IEquals(image, L"explorer.exe") && !IsExplorerTitle(appName)) return false;

    bool running = false;
    for (const auto& p : EnumerateProcesses()) {
        if (IEquals(p.exeName, image)) {
            running = true;
            break;
        }
    }
    if (!running) return false;

    const std::wstring cmd = L"taskkill.exe /f /im \"" + image + L"\"";
    std::vector<wchar_t> buf(cmd.begin(), cmd.end());
    buf.push_back(L'\0');

    STARTUPINFOW si{};
    si.cb = sizeof(si);
    si.dwFlags = STARTF_USESHOWWINDOW;
    si.wShowWindow = SW_HIDE;

    PROCESS_INFORMATION pi{};
    if (!CreateProcessW(nullptr, buf.data(), nullptr, nullptr, FALSE,
                        CREATE_NO_WINDOW, nullptr, nullptr, &si, &pi))
        return false;

    WaitForSingleObject(pi.hProcess, 15000);
    DWORD exitCode = 1;
    GetExitCodeProcess(pi.hProcess, &exitCode);
    CloseHandle(pi.hThread);
    CloseHandle(pi.hProcess);
    return exitCode == 0;
}

int KillProcesses(const std::vector<DWORD>& pids) {
    int killed = 0;
    for (DWORD pid : pids) {
        if (pid == 0 || pid == 4 || pid == GetCurrentProcessId()) continue;
        if (IsSystemImage(FileNameOf(ProcessImagePath(pid)))) continue;
        HANDLE h = OpenProcess(PROCESS_TERMINATE | SYNCHRONIZE, FALSE, pid);
        if (!h) continue;
        if (TerminateProcess(h, 1)) {
            ++killed;
            WaitForSingleObject(h, 400);
        }
        CloseHandle(h);
    }
    return killed;
}
