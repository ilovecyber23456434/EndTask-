#pragma once
#include <windows.h>
#include <string>
#include <vector>

// What the user right-clicked on, on the taskbar.
struct TaskbarHit {
    bool onButton = false;
    std::wstring appId;   // parsed from AutomationId "Appid:..."
    std::wstring title;   // UIA accessible name of the button
};

// Returns onButton=true only when the point is over a taskbar app button.
TaskbarHit HitTestTaskbarButton(POINT pt);

// Maps the hit to the process ids that own the matching windows.
std::vector<DWORD> ResolveProcesses(const TaskbarHit& hit);

// Maps an app display name (the jump-list "Open" row, e.g. "LibreWolf",
// "Settings", "cmd") to processes by executable name and version metadata.
// Used when no visible window matches, which is the normal case for UWP apps
// and for grouped taskbar buttons whose window titles differ from the label.
std::vector<DWORD> ResolveProcessesByName(const std::wstring& appName);

// Last resort: taskkill /f /im "<app>.exe", but only when a process with that
// image name is actually running. Returns true when taskkill exited 0.
bool KillByImageName(const std::wstring& appName);

// Terminates every pid in the list. Returns how many were killed.
int KillProcesses(const std::vector<DWORD>& pids);
